# Frontend integration

This app contains a storefront at `/` and an administrative demonstration at `/vg-admin`. There is no backend, authentication, database connection or payment processing. Reloading resets all changes. Click the footer logo five times rapidly to open the panel, or use `/vg-admin` directly. This is discoverability only, not access control.

The runtime is React + TanStack Start, as required by the Lovable environment. Uploaded Express/MySQL files are reference material and are not executed.

## Data boundary

`src/lib/store-data.ts` exports demo records using the field names of `banco.sql`. `src/lib/store-context.tsx` owns the shared in-memory state used by both pages. Replace these with your authenticated API adapter. Do not read MySQL credentials in browser code.

The two supplied SQL schemas differ. This frontend uses `banco.sql`: `em_separacao`, numeric `classificacao_indicativa`, payment method `cartao`, platform `slug`. The alternate schema is not merged.

## Available interactions

- Store: rotating featured games, search, platform filter, catalog ordering, product details, wishlist, cart quantities and stock limits.
- Panel: animated overview, period simulation, searchable/sortable tables, status filters, pagination, CSV export, in-memory create/edit/delete where appropriate, order status and tracking edit, client type/active edit, coupon generation, read-only payments/reviews/carts/wishlists and related items.
- Product stock edits are reflected in the storefront during the same visit.
- Related tables are accessible through order and cart tabs and customer address navigation.

## Team implementation responsibilities

Implement real authentication and server-enforced admin permissions, record validation and referential integrity, session persistence, cart merging, stock transactions, order creation/cancellation/refunds, secure checkout and review eligibility. Never use client-side totals as trusted payment values. Admin deletion and edits in this demo do not enact database cascades or financial side effects. Dashboard chart series are explicitly simulated; real aggregated metrics should replace them. No real credentials are included. Sample emails use example.com.
