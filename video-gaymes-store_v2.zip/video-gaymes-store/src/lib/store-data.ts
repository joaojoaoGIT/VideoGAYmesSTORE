import elden from '@/assets/elden-ring.asset.json';
import cyberpunk from '@/assets/cyberpunk.asset.json';
import gta from '@/assets/gta.asset.json';
import hogwarts from '@/assets/hogwarts.asset.json';
import baldurs from '@/assets/baldurs-gate.asset.json';
import spider from '@/assets/spider-man.asset.json';
export type Product = {id:number;nome:string;slug:string;descricao:string;desenvolvedora:string;publicadora:string;preco:number;preco_promocional:number;estoque:number;categoria_id:number;plataforma_id:number;imagem_url:string;trailer_url:string;classificacao_indicativa:number;data_lancamento:string;ativo:number;destaque:number};
export const platforms = ['Todas as plataformas','PC','PlayStation 5','Xbox Series','Nintendo Switch'];
export const categories = ['RPG','Ação e aventura','Mundo aberto','Corrida','Esportes','Indie'];
const games = [
 ['Elden Ring',elden.url,249.90,149.90,1,18,'FromSoftware','Um mundo vasto. Uma jornada inesquecível. Torne-se o próximo Lorde Prístino.'],
 ['Cyberpunk 2077',cyberpunk.url,199.90,99.90,1,25,'CD Projekt Red','Entre em Night City e escreva sua história como um mercenário lendário.'],
 ['Hogwarts Legacy',hogwarts.url,249.90,124.90,2,7,'Avalanche Software','Sua carta chegou. Descubra a magia e os segredos de Hogwarts.'],
 ["Baldur’s Gate 3",baldurs.url,199.90,159.90,1,12,'Larian Studios','Reúna seu grupo e viva uma aventura em que cada escolha importa.'],
 ['Grand Theft Auto V',gta.url,149.90,59.90,3,32,'Rockstar Games','Três protagonistas. Uma cidade. Possibilidades sem limites em Los Santos.'],
 ['Marvel’s Spider-Man',spider.url,249.90,149.90,2,6,'Insomniac Games','Vista a máscara e proteja Nova York em uma aventura espetacular.'],
] as const;
export const initialProducts:Product[] = games.map((g,i)=>({id:i+1,nome:g[0],slug:g[0].toLowerCase().replace(/[^a-z0-9]+/g,'-'),imagem_url:g[1],preco:g[2],preco_promocional:g[3],plataforma_id:g[4],estoque:g[5],desenvolvedora:g[6],publicadora:g[6],descricao:g[7],categoria_id:i%3+1,trailer_url:'',classificacao_indicativa:16,data_lancamento:'2023-02-10',ativo:1,destaque:i<3?1:0}));
export const money=(value:number)=>new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'}).format(value);
export type Row=Record<string,string|number>;
export const initialTables:Record<string,Row[]>={
 categorias:categories.map((nome,i)=>({id:i+1,nome,slug:nome.toLowerCase().replace(/\s+/g,'-'),descricao:`Jogos de ${nome.toLowerCase()}`})),
 plataformas:platforms.slice(1).map((nome,i)=>({id:i+1,nome,slug:nome.toLowerCase().replace(/\s+/g,'-')})),
 usuarios:[{id:1,nome:'Lucas Almeida',email:'lucas@example.com',cpf:'',telefone:'',tipo:'cliente',ativo:1},{id:2,nome:'Mariana Costa',email:'mariana@example.com',cpf:'',telefone:'',tipo:'cliente',ativo:1},{id:3,nome:'Pedro Santos',email:'pedro@example.com',cpf:'',telefone:'',tipo:'cliente',ativo:1}],
 pedidos:[{id:1,codigo:'VG-20261008-A4X2',usuario_id:1,endereco_entrega:'São Paulo, SP',status:'pago',subtotal:309.8,desconto:0,frete:0,total:309.8,codigo_rastreio:'',criado_em:'2026-10-08'},{id:2,codigo:'VG-20261008-B8K5',usuario_id:2,endereco_entrega:'Curitiba, PR',status:'em_separacao',subtotal:149.9,desconto:0,frete:19.9,total:169.8,codigo_rastreio:'',criado_em:'2026-10-08'},{id:3,codigo:'VG-20261007-C3M7',usuario_id:3,endereco_entrega:'Rio de Janeiro, RJ',status:'enviado',subtotal:124.9,desconto:0,frete:19.9,total:144.8,codigo_rastreio:'BR123456789',criado_em:'2026-10-07'},{id:4,codigo:'VG-20261007-D5P9',usuario_id:1,endereco_entrega:'São Paulo, SP',status:'entregue',subtotal:99.9,desconto:0,frete:19.9,total:119.8,codigo_rastreio:'BR987654321',criado_em:'2026-10-07'}],
 pagamentos:[{id:1,pedido_id:1,metodo:'pix',status:'aprovado',valor:309.8,parcelas:1,bandeira:'',ultimos_digitos:'',transacao_id:'DEMO-A4X2'},{id:2,pedido_id:2,metodo:'cartao',status:'aprovado',valor:169.8,parcelas:2,bandeira:'Visa',ultimos_digitos:'4242',transacao_id:'DEMO-B8K5'}],
 cupons:[{id:1,codigo:'PLAY10',tipo:'percentual',valor:10,valor_minimo:100,usos_maximos:100,usos_atuais:38,validade:'2026-10-31',ativo:1},{id:2,codigo:'BEMVINDO',tipo:'fixo',valor:20,valor_minimo:150,usos_maximos:50,usos_atuais:12,validade:'2026-11-30',ativo:1}],
 avaliacoes:[{id:1,produto_id:1,usuario_id:1,nota:5,comentario:'Uma das melhores experiências que já tive.'},{id:2,produto_id:2,usuario_id:2,nota:4,comentario:'Night City está incrível!'}],
 enderecos:[{id:1,usuario_id:1,cep:'01001000',logradouro:'Praça da Sé',numero:'10',complemento:'',bairro:'Sé',cidade:'São Paulo',estado:'SP',principal:1}],
 carrinhos:[{id:1,usuario_id:2,atualizado_em:'2026-10-08'}],carrinho_itens:[{id:1,carrinho_id:1,produto_id:3,quantidade:1}],lista_desejos:[{id:1,usuario_id:1,produto_id:4,criado_em:'2026-10-08'}],pedido_itens:[{id:1,pedido_id:1,produto_id:1,nome_produto:'Elden Ring',preco_unitario:149.9,quantidade:1},{id:2,pedido_id:1,produto_id:4,nome_produto:'Baldur’s Gate 3',preco_unitario:159.9,quantidade:1}],pedido_cupons:[]};
