import {useState} from 'react';
import {User,LogOut,CreditCard,Package,Plus,Check,Wallet} from 'lucide-react';
import {toast} from 'sonner';
import {Button} from '@/components/ui/button';
import {Dialog,DialogContent,DialogTitle,DialogDescription} from '@/components/ui/dialog';
import {useStore,type GameCard} from '@/lib/store-context';
import {money} from '@/lib/store-data';

const field='w-full';
const label='text-xs text-muted-foreground';
const masked=(n:string)=>`•••• ${n.slice(-4)}`;

function Field({id,text,...p}:{id:string;text:string}&React.InputHTMLAttributes<HTMLInputElement>){return <div className="grid gap-1"><label className={label} htmlFor={id}>{text}</label><input id={id} className={field} {...p}/></div>}

export function CardForm({onDone}:{onDone:(c:GameCard)=>void}){
  const {user,setCards}=useStore();const [f,setF]=useState({apelido:'Meu VG Pay',titular:user?.nome??'',numero:'',validade:''});
  const save=():void=>{const num=f.numero.replace(/\D/g,'');if(!user)return;if(num.length<12){toast.error('Número precisa ter ao menos 12 dígitos.');return}if(!/^\d{2}\/\d{2}$/.test(f.validade)){toast.error('Validade no formato MM/AA.');return}if(!f.titular.trim()){toast.error('Informe o titular.');return}
    const card:GameCard={id:Date.now(),usuario_id:user.id,apelido:f.apelido||'VG Pay',titular:f.titular,numero:num,bandeira:'VG Pay',validade:f.validade,saldo:1500};setCards(c=>[...c,card]);toast.success('Cartão VG Pay criado com R$ 1.500 de saldo fictício!');onDone(card)};
  return <div className="grid gap-3 rounded-lg border border-border p-4"><p className="text-sm flex items-center gap-2"><Wallet className="size-4 text-primary"/>VG Pay — cartão fictício para testar compras. Nenhum dado real é cobrado.</p>
    <Field id="card-name" text="Apelido" value={f.apelido} onChange={e=>setF({...f,apelido:e.target.value})}/>
    <Field id="card-holder" text="Titular" value={f.titular} onChange={e=>setF({...f,titular:e.target.value})}/>
    <div className="grid grid-cols-2 gap-3"><Field id="card-number" text="Número (inventado)" inputMode="numeric" placeholder="0000 0000 0000" value={f.numero} onChange={e=>setF({...f,numero:e.target.value.replace(/[^\d ]/g,'').slice(0,19)})}/><Field id="card-exp" text="Validade" placeholder="MM/AA" value={f.validade} onChange={e=>setF({...f,validade:e.target.value.slice(0,5)})}/></div>
    <Button onClick={save}><Plus/>Cadastrar VG Pay</Button></div>
}

export function AccountDialog({open,onOpenChange}:{open:boolean;onOpenChange:(o:boolean)=>void}){
  const {user,setUser,customers,setCustomers,setTables,tables,cards}=useStore();
  const [mode,setMode]=useState<'entrar'|'cadastrar'>('entrar');const [f,setF]=useState({nome:'',email:'',senha:'',confirmar:''});const [addCard,setAddCard]=useState(false);
  const login=()=>{const c=customers.find(c=>c.email.toLowerCase()===f.email.trim().toLowerCase());if(!c||c.senha!==f.senha){toast.error('E-mail ou senha incorretos.');return}setUser(c);setF({nome:'',email:'',senha:'',confirmar:''});toast.success(`Bem-vindo de volta, ${c.nome.split(' ')[0]}!`)};
  const signup=()=>{const email=f.email.trim().toLowerCase();if(f.nome.trim().length<3){toast.error('Informe seu nome.');return}if(!/^\S+@\S+\.\S+$/.test(email)){toast.error('E-mail inválido.');return}if(customers.some(c=>c.email===email)){toast.error('Esse e-mail já tem conta.');return}if(f.senha.length<6){toast.error('Senha com no mínimo 6 caracteres.');return}if(f.senha!==f.confirmar){toast.error('As senhas não conferem.');return}
    const id=Math.max(0,...customers.map(c=>c.id),...(tables['usuarios']??[]).map(u=>Number(u['id'])))+1;const c={id,nome:f.nome.trim(),email,senha:f.senha,cpf:'',telefone:''};setCustomers(l=>[...l,c]);setTables(t=>({...t,usuarios:[...(t['usuarios']??[]),{id,nome:c.nome,email,cpf:'',telefone:'',tipo:'cliente',ativo:1}]}));setUser(c);toast.success('Conta criada! Cadastre seu VG Pay para comprar.')};
  const orders=user?(tables['pedidos']??[]).filter(p=>p['usuario_id']===user.id):[];const mine=cards.filter(c=>c.usuario_id===user?.id);
  return <Dialog open={open} onOpenChange={onOpenChange}><DialogContent className="max-h-[90vh] overflow-y-auto">
    {!user?<><DialogTitle>{mode==='entrar'?'Entrar na sua conta':'Criar conta de cliente'}</DialogTitle><DialogDescription>{mode==='entrar'?'Teste com lucas@example.com / demo123.':'Leva 10 segundos. É tudo demonstração.'}</DialogDescription>
      <div className="grid grid-cols-2 gap-2">{(['entrar','cadastrar'] as const).map(m=><Button key={m} variant={mode===m?'default':'outline'} onClick={()=>setMode(m)}>{m==='entrar'?'Entrar':'Cadastrar'}</Button>)}</div>
      <form className="grid gap-3" onSubmit={e=>{e.preventDefault();mode==='entrar'?login():signup()}}>
        {mode==='cadastrar'&&<Field id="acc-name" text="Nome completo" value={f.nome} onChange={e=>setF({...f,nome:e.target.value})}/>}
        <Field id="acc-email" text="E-mail" type="email" placeholder="voce@email.com" value={f.email} onChange={e=>setF({...f,email:e.target.value})}/>
        <Field id="acc-pass" text="Senha" type="password" value={f.senha} onChange={e=>setF({...f,senha:e.target.value})}/>
        {mode==='cadastrar'&&<Field id="acc-confirm" text="Confirmar senha" type="password" value={f.confirmar} onChange={e=>setF({...f,confirmar:e.target.value})}/>}
        <Button type="submit"><User/>{mode==='entrar'?'Entrar':'Criar conta'}</Button></form></>
    :<><DialogTitle>Olá, {user.nome.split(' ')[0]}!</DialogTitle><DialogDescription>{user.email}</DialogDescription>
      <section className="grid gap-2"><h4 className="font-semibold flex items-center gap-2"><CreditCard className="size-4"/>Pagamento</h4>
        {mine.map(c=><div key={c.id} className="flex justify-between rounded-lg border border-border p-3 text-sm"><span>{c.apelido} · {masked(c.numero)}</span><strong className="text-primary">{money(c.saldo)}</strong></div>)}
        {addCard?<CardForm onDone={()=>setAddCard(false)}/>:<Button variant="outline" onClick={()=>setAddCard(true)}><Plus/>Cadastrar cartão VG Pay</Button>}</section>
      <section className="grid gap-2"><h4 className="font-semibold flex items-center gap-2"><Package className="size-4"/>Meus pedidos</h4>
        {orders.length?orders.map(o=><div key={String(o['id'])} className="flex justify-between text-sm rounded-lg border border-border p-3"><span>{String(o['codigo'])} · {String(o['status'])}</span><strong>{money(Number(o['total']))}</strong></div>):<p className="text-sm text-muted-foreground">Nenhum pedido ainda.</p>}</section>
      <Button variant="ghost" onClick={()=>{setUser(null);toast.info('Você saiu da conta.')}}><LogOut/>Sair</Button></>}
  </DialogContent></Dialog>
}

export function CheckoutDialog({open,onOpenChange,onNeedLogin}:{open:boolean;onOpenChange:(o:boolean)=>void;onNeedLogin:()=>void}){
  const {user,cart,setCart,products,setProducts,cards,setCards,tables,setTables}=useStore();
  const mine=cards.filter(c=>c.usuario_id===user?.id);const [cardId,setCardId]=useState<number|null>(null);const [addr,setAddr]=useState('');const [done,setDone]=useState('');
  const items=Object.entries(cart).map(([id,q])=>({p:products.find(p=>p['id']===Number(id))!,q})).filter(i=>i.p);
  const price=(p:{preco:number;preco_promocional:number})=>p.preco_promocional>0?p.preco_promocional:p.preco;const subtotal=items.reduce((s,i)=>s+price(i.p)*i.q,0);const frete=subtotal>=299||!subtotal?0:19.9;const total=subtotal+frete;
  const selected=mine.find(c=>c.id===cardId)??mine[0];
  const pay=()=>{if(!user)return;if(!selected){toast.error('Cadastre um VG Pay primeiro.');return}if(addr.trim().length<5){toast.error('Informe o endereço de entrega.');return}if(selected.saldo<total){toast.error('Saldo VG Pay insuficiente.');return}
    const pid=Math.max(0,...(tables['pedidos']??[]).map(p=>Number(p['id'])))+1;const codigo=`VG-${new Date().toISOString().slice(0,10).replace(/-/g,'')}-${Math.random().toString(36).slice(2,6).toUpperCase()}`;
    setTables(t=>({...t,pedidos:[...(t['pedidos']??[]),{id:pid,codigo,usuario_id:user.id,endereco_entrega:addr,status:'pago',subtotal,desconto:0,frete,total,codigo_rastreio:'',criado_em:new Date().toISOString().slice(0,10)}],
      pedido_itens:[...(t['pedido_itens']??[]),...items.map((i,k)=>({id:Date.now()+k,pedido_id:pid,produto_id:i.p['id'],nome_produto:i.p.nome,preco_unitario:price(i.p),quantidade:i.q}))],
      pagamentos:[...(t['pagamentos']??[]),{id:Date.now(),pedido_id:pid,metodo:'cartao',status:'aprovado',valor:total,parcelas:1,bandeira:'VG Pay',ultimos_digitos:selected.numero.slice(-4),transacao_id:`DEMO-${codigo.slice(-4)}`}]}));
    setCards(cs=>cs.map(c=>c.id===selected.id?{...c,saldo:c.saldo-total}:c));setProducts(ps=>ps.map(p=>cart[p['id']]?{...p,estoque:p.estoque-(cart[p['id']]??0)}:p));setCart({});setDone(codigo);toast.success('Pagamento aprovado!')};
  return <Dialog open={open} onOpenChange={o=>{onOpenChange(o);if(!o)setDone('')}}><DialogContent className="max-h-[90vh] overflow-y-auto"><DialogTitle>{done?'Pedido confirmado':'Finalizar compra'}</DialogTitle>
    {done?<><DialogDescription>Pedido {done} pago com VG Pay. Ele aparece em Minha conta e no painel.</DialogDescription><Check className="mx-auto size-14 text-primary animate-in zoom-in"/><Button onClick={()=>onOpenChange(false)}>Continuar comprando</Button></>
    :!user?<><DialogDescription>Entre ou crie sua conta para pagar.</DialogDescription><Button onClick={onNeedLogin}><User/>Entrar / Cadastrar</Button></>
    :<><DialogDescription>{items.length} itens · total {money(total)}{frete?` (frete ${money(frete)})`:' · frete grátis'}</DialogDescription>
      <Field id="ck-addr" text="Endereço de entrega" placeholder="Rua, número, cidade - UF" value={addr} onChange={e=>setAddr(e.target.value)}/>
      {mine.length?<div className="grid gap-2">{mine.map(c=><Button key={c.id} variant={selected?.id===c.id?'default':'outline'} className="justify-between" onClick={()=>setCardId(c.id)}><span className="flex items-center gap-2"><CreditCard/>{c.apelido} · {masked(c.numero)}</span><span>{money(c.saldo)}</span></Button>)}</div>:<CardForm onDone={c=>setCardId(c.id)}/>}
      <Button disabled={!items.length} onClick={pay}><Wallet/>Pagar {money(total)}</Button></>}
  </DialogContent></Dialog>
}
