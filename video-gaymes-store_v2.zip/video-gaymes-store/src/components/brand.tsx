export function Brand(){return <div className="brand">Video Gay<em>(mes)</em><small>STORE</small></div>}
