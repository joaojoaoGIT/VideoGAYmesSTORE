<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Application rules
- Keep storefront and administration as separate TanStack routes, with shared in-memory state in StoreProvider; this allows colleagues to replace the demo adapter without coupling presentation to a backend.
- Use banco.sql field names and enum values in demo records and admin forms; this preserves compatibility with the supplied canonical schema.
- Admin is a public frontend demonstration, not an authentication boundary; production authorization and all payment operations must be implemented by the integration team.
